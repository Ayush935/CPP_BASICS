#include <iostream>

// scope resolution operator :: can't  be used in the friend function

class plug{
    int a;
    int b;

    public:
    plug():a(0),b(0){

    }
    plug(int c,int d):a(c),b(d){
    
    }
    plug operator +(int n){
       plug temp ;
       temp.a = a + n;
       temp.b = b + n;
       return temp;
    }
    void sh(){
        std::cout<<" a "<<a<<" b "<<b;
    }

    friend  std::ostream& operator <<(std::ostream &t,plug &p){
       t<<p.a<<" "<<p.b;
       return t;
    }

    friend  std::istream& operator >>(std::istream &ti,plug &p){
       ti>>p.a>>p.b;
       return ti;
    }

    friend plug operator +(int n,plug &p){
        plug temp;
        temp.a = n+p.a;
        temp.b = n+p.b;
        return temp;
    }
};

int main(){
    plug p(2,4);
    plug p2=p+4;

    p2.sh();
    plug p8 = 10 + p2;
    
    plug p6;
    std::cin>>p6;
    std::cout<<p6;
    std::cout<<p8;

    

}