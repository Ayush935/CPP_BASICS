#include "date.h"

class bill{
   int billnumber;
   customer p;
   date d;
   int billamount;

   public:
   bill();
   ~bill();
   void accept();
   friend std::ostream& operator <<(std::ostream&,bill &s);
   

   int getBillnumber() const { return billnumber; }
   void setBillnumber(int billnumber_) { billnumber = billnumber_; }

   customer getP() const ;
   void setP(const customer &p_) { p = p_; }

   date getD() const { return d; }
   void setD(const date &d_) { d = d_; }

   int getBillamount() const { return billamount; }
   void setBillamount(int billamount_) { billamount = billamount_; }
   
};