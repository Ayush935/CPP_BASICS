#include "bill.h"

int main(){

    bill on[3];
    for(int i=0;i<3;i++){
        std::cout<<"enter details ";
        on[i].accept();
    }
    for(int i=0;i<3;i++){
        std::cout<<on[i];
    }
    
}