#include "customer.h"

customer::customer()
{   
   
}

customer::customer(const char *pn)
{
    customername=new char[strlen(pn)+1];
    strcpy(customername, pn);
}

customer::customer(const customer &p)
{
    customername=new char[strlen(p.customername)+1];
    strcpy(customername,p.customername);
}
customer::~customer()
{
    delete []customername;
}
void customer::accept()
{
   char *a=new char[10];
   std::cout<<"name";
   std::cin>>a;
   strcpy(customername,a);
}
 std::ostream& operator <<(std::ostream& pn,customer &s)
{
   pn<<"customer name is"<<s.customername;
   return pn;
}
