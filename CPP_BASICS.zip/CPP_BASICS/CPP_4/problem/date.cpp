#include "date.h"


date::date(){};

date::date(int a,int b,int c):day(a),month(b),year(c){}

std::ostream& operator <<(std::ostream&pn,date &s){
   pn<<s.getDay()<<" "<<s.getMonth()<<" "<<s.getYear();
   return pn;
}

void date::accept(){
    int day,month,year;
    std::cin>>day>>month>>year;
    
}