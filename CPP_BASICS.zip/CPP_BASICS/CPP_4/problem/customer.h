#include <iostream>
#include <cstring>

class customer{
   char *customername;

   public:
   customer();
   customer(const char *pn);
   customer(const customer &);
   
   ~customer();
   void accept();

   char *getCustomername() const { return customername; }
   void setCustomername(char *customername_) { strcpy(customername,customername_); }

   friend std::ostream& operator <<(std::ostream&,customer &s);
   
};