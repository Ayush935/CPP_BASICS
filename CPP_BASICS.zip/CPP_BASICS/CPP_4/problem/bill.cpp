#include "bill.h"

bill::bill():billnumber(0),billamount(0){
  
}

bill::~bill(){
   
}

customer bill::getP() const{
    return p;
}

void bill::accept(){
    std::cout<<"billnumber";
    std::cin>>billnumber;

    std::cout<<"customer name";
    p.accept();

    std::cout<<"enter bill date";
    d.accept();

    std::cout<<"enter bill amount";
    std::cin>>billamount;


}

std::ostream& operator <<(std::ostream&ps,bill &s){
       ps<<" Bill num is"<<s.billnumber<<"\n"<<
       "cust info "<<s.p<<"/n"<<" bill date "<<s.d<<"/n"<<" Bill Amount "<<s.billamount;
       return ps;
    }