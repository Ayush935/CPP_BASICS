#include <iostream>

class point{
    int x;
    int y;
    public:
    point(){};
    point(int a,int b):x(a),y(b){};
    void sh(){
        std::cout<<"value a"<<x<<" value b "<<y;
    }

};
class helper{
    point *p;
    public:
    helper(){
        p=new point;
    };
    helper(int a,int b){
        p=new point(a,b);
    };
    ~helper(){
        delete p;
    }
    point *operator ->(){
         return p;
    }
    

};

int main(){

    helper obj(4,5);
    obj->sh();

}