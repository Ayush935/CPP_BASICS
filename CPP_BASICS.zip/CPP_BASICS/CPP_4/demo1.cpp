#include <iostream>


class point{
    int *marks;

    public:
    point(){

    }
    
    friend std::istream& operator >>(std::istream &t,point &c){
        c.marks = new int[3];
        for(int i=0;i<3;i++){
            t>>c.marks[i];
        }
        return t;
    }

    friend std::ostream& operator <<(std::ostream &ti,point &c){
        
        for(int i=0;i<3;i++){
            ti<<c.marks[i]<<" ";
        }
        return ti;
    }
    ~point(){
        delete[] marks;
    }

};

int main(){

  

    point p;
    

    std::cin>>p;
    std::cout<<p;

}