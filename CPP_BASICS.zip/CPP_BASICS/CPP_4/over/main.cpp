#include"op.h"
int main(){
    Point p;
    p.display();

    Point p1=p++;
    p1.display();
    p.display();

    Point p2=++p;
    p2.display();
    p.display();

    Point p3=p-p1;
    p3.display();

    Point p4=p3+3;
    p4.display();

    std::cout<<p4<<p3;  
    /*
    cout.operator<<(p4);
    cout ->ostream 
    friend 

    
    */

   Point p5;
   std::cin>>p5;

   std::cout<<p5;

   Point p6=(p1+p2)*p;

   std::cout<<p6;

   Point p7=~p2;
   std::cout<<p7;
    

}


