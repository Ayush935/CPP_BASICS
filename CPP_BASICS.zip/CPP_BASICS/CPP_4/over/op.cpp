#include"op.h"

Point::Point():x(2),y(3){
    // std::cout<<"\nConstructor called ";
}

Point::Point(int a,int b):x(a),y(b){
    std::cout<<"\nParameterised constructor called ";
}

void Point::display(){
    std::cout<<"\n"<<x<<"  "<<y;
}

Point Point::operator-(Point &p){
    Point tempobj=*this;
    tempobj.x=this->x-p.x;
    tempobj.y=this->y-p.y;
    return tempobj;
}

Point Point::operator-(){
    Point tempobj=*this;
    tempobj.x=-tempobj.x;
    tempobj.y=-tempobj.y;
    return tempobj;
}

Point& Point::operator++(){
    ++x;
    ++y;
    return *this;
}

Point Point::operator++(int){
    Point tempobj=*this;
    x++;
    y++;
    return tempobj;
}

Point Point::operator+(Point &p){
    Point tempobj;
    tempobj.x=(this->x+p.x);
    tempobj.y=(this->y+p.y);
    return tempobj;
}

bool Point::operator==(Point &p){
    return (x==p.x && y==p.y);
    
}

bool Point::operator!=(Point &p){
    return (x!=p.x || y!=p.y);
}

Point Point::operator<<(Point &p){
    Point tempobj;
    tempobj.x=this->x<<p.x;
    tempobj.y=this->y<<p.y;
    return tempobj;
}


Point Point::operator>>(Point &p){
    Point tempobj;
    tempobj.x=x>>p.x;
    tempobj.y=y>>p.y;
    return tempobj;
}

Point Point::operator+(int a){
    Point tempobj;
    tempobj.x=x+a;
    tempobj.y=y+a;
    return tempobj;
}


Point operator+(int a,Point &p){
    Point temp;
    temp.x= a + p.x;
    temp.y =a+p.y;
    return temp;
}


std::ostream& operator<<(std::ostream &os,Point &p){
    os<<"\n"<<p.x<<" "<<p.y;
    return os;
}

std::istream& operator>>(std::istream &is,Point &p){
    is>>p.x>>p.y;
    return is;
}

Point Point::operator*(Point &p){
    Point tempobj;
    tempobj.x=x*p.x;
    tempobj.y=y*p.y;
    return tempobj;
}

Point Point::operator~(){
    Point tempobj=*this;
    tempobj.x=~tempobj.x;
    tempobj.y=~tempobj.y;
    return tempobj;
}

void Point::operator()(){
    display();
}

// char& Point::operator[](int index){
//     return str[index];
// }

//in cpp return by reference auto adjust the function call
/*

example-> 
Student s1;
char ch=s1[0];  --> ch = s1.operator[](0);
s1[1]="E";      --> s1.operator[](1) = 'E';


*/

