#ifndef OP_H
#define OP_H


#include<iostream>

class Point {
    int x,y;

    public:

    Point();
    Point(int a,int b);
    Point operator-(Point &p);
    bool operator==(Point &p);
    bool operator!=(Point &p);
    Point&  operator++();//preincrement operator
    Point operator++(int); //postincrement operator
    Point operator-();
    Point operator+(int a);
    Point operator+(Point &p);
    Point operator<<(Point &p);
    Point operator>>(Point &p);
    Point operator*(Point &p);
    Point operator~();
    void operator()(); //function call operator
    void display();



    friend std::istream& operator>>(std::istream &is,Point &p);

    friend Point operator+(int n,Point &p);
    //friend keyword is required in the declaration not in defination

    //:: it is not required while defining friend function as it is not a member function

    friend std::ostream& operator<<(std::ostream &os,Point &p);
  
    /*
    cout is an obect of ostream class
    to make cout<<p3 valid we need to overload << in ostream class
    but we cannot edit std file
    thus friend function

    cout<<p3<<p4; this is cascading effect;
    if the return type is void then cout<<p3 will be void so void<<p4 is not possible
    thus std::ostream& should be the return type 

    */


//    char& operator[](int index);



};

#endif // OP_H
