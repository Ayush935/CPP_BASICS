#include "student.h"

int student::pi= 1000;

student::student(){
    p = new char[10];
    strcpy(p,"Joy");
    pi++;
    m=pi;
    mk=new int[3];
    mk[0]=23;
    mk[1]=34;
    mk[2]=56;
}

student::student(const char*so,int *s){
    p=new char[strlen(so)+1];
    strcpy(p,so);
    pi++;
    m=pi;
    mk=new int[3];
    for(int i=0;i<3;i++){
        mk[i]=s[i];
    }
}

student::student(const student &c){
    this->m=c.m;
    p=new char(strlen(c.p)+1);
    strcpy(p,c.p);
    mk =new int [3];
for(int i=0;i<3;i++){
    mk[i]=c.mk[i];
}
    
}

// void student::display(){
//     std::cout<<
// }

student::~student(){
    delete[] mk;
    delete[] p;
}

