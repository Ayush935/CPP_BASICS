#include "student.h"

int main(){
    int mk[3]={23,34,45};
    student s1("bob",mk);
    s1.display();
    student s2(s1);
    s2.display();
}