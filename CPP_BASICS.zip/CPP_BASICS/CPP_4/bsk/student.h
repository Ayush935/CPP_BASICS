#include <iostream>
#include <cstring>

class student{
   int m;
   char *p;
   int *mk;
   static int pi;

   public:
   student();
   student(const char *,int *);
   ~student();
   student(const student &c);
   void calc();
   void accept();

   int getM() const { return m; }
  
   char *getP() const { return p; }
   void setP(char *p_) { strcpy(p,p_); }
   void display(){
      std::cout<<m<<p;
      for(int i=0;i<3;i++){
         std::cout<<mk[i];
      }
   }
   
};

// void getname();
// void high();


