#include "bank.h"

bank::bank():acc_no(123),acc_name("SBI"){

    mks = new int(3);
    mks[0]=45;
    mks[1]=46;
    mks[2]=48;
    std::cout<<"const called"<<std::endl;

}

bank::bank(int a,std::string nm,int *k):acc_no(a),acc_name(nm){
    mks = new int[3];
    for(int i=0;i<3;i++){
        mks[i]=k[i];
    }
    std::cout<<"para const call "<<std::endl;
}

int bank::high_mk(){
    int sum=0;
    for(int i=0;i<3;i++){
        sum+=mks[i];
    }
    return sum;
}

bank::~bank(){
    delete[] mks;
    std::cout<<"dest called"<<std::endl;
}