#include "bank.h"

void name(int n,bank *s[]){
   for(int i=0;i<2;i++){
    if(s[i]->getaccNo()==n){
        std::cout<<"got it"<<std::endl;
        break;
    }
   }
}

int main(){
    bank *p[2];
    int m1[3]={12,34,45};
    int m2[3]={23,34,54};
    p[0]=new bank(34,"bon",m1);
    p[1]=new bank(54,"john",m2);
    name(34,p);
    
    for(int i=0;i<2;i++){
        delete p[i];
    }

}