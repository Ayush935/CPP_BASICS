#include <iostream>


class bank{

    int acc_no;
    std::string acc_name;
    int *mks;

    public:
    bank();
    bank(int,std::string,int *);
    int high_mk();
    ~bank();

    int getaccNo() const { return acc_no; }
    void setAccNo(int accNo) { acc_no = accNo; }

    std::string getaccName() const { return acc_name; }
    void setAccName(const std::string &accName) { acc_name = accName; }

    // int *getMks() const { return mks; }
    // void setMks(int *mks_) { mks = mks_; }

    

};

void name(int n,bank *s[]);