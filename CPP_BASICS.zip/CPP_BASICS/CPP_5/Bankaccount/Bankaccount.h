#ifndef BANKACCOUNT_H
#define BANKACCOUNT_H

#include <iostream>

class bankaccount
{
   std::string name;
   int acc_no;

   public:
   bankaccount();
   bankaccount(std::string,int);
   friend std::ostream& operator <<(std::ostream&,bankaccount &);
   friend std::istream& operator >>(std::istream&,bankaccount &);
   ~bankaccount();
   int withdrawal();
};

#endif // BANKACCOUNT_H
