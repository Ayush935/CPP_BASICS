#ifndef PERSON2_H
#define PERSON2_H

#include "person.h"

class person2:public person
{
    int Ifc_code;

    public:
    person2();
    person2(std::string,int,int,int);
    friend std::ostream& operator <<(std::ostream&,person2 &);
    friend std::istream& operator >>(std::istream&,person2 &);
    ~person2();

};

#endif // PERSON2_H
