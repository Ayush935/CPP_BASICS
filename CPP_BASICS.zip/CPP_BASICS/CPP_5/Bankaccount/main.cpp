#include "person2.h"

int main(){
    person p1;
    std::cin>>p1;
    std::cout<<p1;

    person2 z1;
    std::cin>>z1;
    std::cout<<z1;

}