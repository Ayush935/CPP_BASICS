#include "Bankaccount.h"

bankaccount::bankaccount():name("Bob"),acc_no(1022)
{
   std::cout<<"bankaccount def const is call"<<std::endl;
}

bankaccount::bankaccount(std::string nm,int num):name(nm),acc_no(num)
{
   std::cout<<"bankaccount para const is call"<<std::endl;
}

std::ostream& operator <<(std::ostream& out,bankaccount &p)
{
   out<<"Name of acc_holder"<<"\n"<<p.name<<"\n";
   out<<"Account Number"<<"\n"<<p.acc_no<<"\n";
   return out;
}
std::istream& operator >>(std::istream& in,bankaccount &p)
{
   std::cout<<"Enter the Name"<<"\n";
   in >> p.name;
   std::cout<<"Enter the acc_no"<<"\n";
   in >> p.acc_no;
   return in;
}

bankaccount::~bankaccount()
{
   std::cout<<"bankaccount Dest called"<<std::endl;
}

int bankaccount::withdrawal()
{
    return acc_no;
}