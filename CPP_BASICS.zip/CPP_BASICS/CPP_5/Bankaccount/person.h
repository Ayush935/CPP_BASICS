#ifndef PERSON_H
#define PERSON_H

#include "Bankaccount.h"

class person:public bankaccount
{
    int number_of_passbooks;
    
    public:
    person();
    person(std::string,int,int);
    friend std::ostream& operator <<(std::ostream&,person &);
    friend std::istream& operator >>(std::istream&,person &);
    ~person();
};

#endif // PERSON_H
