#include "person2.h"

person2::person2():Ifc_code(100)
{
    std::cout<<"person2 def const call"<<std::endl;
}

person2::person2(std::string nm,int num,int np,int zp):person(nm,num,np),Ifc_code(np)
{
    std::cout<<"person2 para const call"<<std::endl;
}

std::ostream& operator <<(std::ostream& out,person2 &p)
{
    out<<static_cast<person &>(p);
    out<<"IFC CODE"<<p.Ifc_code<<"\n";
    out<<"Withdrawal"<<p.withdrawal();
    return out;
}

std::istream& operator >>(std::istream&in,person2 &p)
{
    in>>static_cast<person &>(p);
    std::cout<<"Enter IFC Code"<<std::endl;
    in>>p.Ifc_code;
    return in;
}

person2::~person2()
{
    std::cout<<"Dest person 2 call"<<std::endl;
}