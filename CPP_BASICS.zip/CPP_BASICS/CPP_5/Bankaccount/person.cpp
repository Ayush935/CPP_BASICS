#include "person.h"

person::person():number_of_passbooks(50)
{
   std::cout<<"person def cons call"<<std::endl;
}

person::person(std::string nm,int num,int np):bankaccount(nm,num),number_of_passbooks(np)
{
    std::cout<<"person para const call"<<std::endl;
}

std::ostream& operator <<(std::ostream& out,person &p)
{
    out<<static_cast<bankaccount &>(p);
    out<<"NUmber of passbooks"<<p.number_of_passbooks<<"\n";
    out<<"Withdrawal"<<p.withdrawal();
    return out;
}

std::istream& operator >>(std::istream&in,person &p)
{
    in>>static_cast<bankaccount &>(p);
    std::cout<<"Enter number of passbooks"<<std::endl;
    in>>p.number_of_passbooks;
    return in;
}

person::~person()
{
    std::cout<<"dest person call"<<std::endl;
}