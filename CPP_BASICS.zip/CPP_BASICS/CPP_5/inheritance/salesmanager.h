#ifndef SALESMANAGER_H
#define SALESMANAGER_H

#include "salesperson.h"

class doortodoor:public salesperson
{
   int houses;

   public:
     doortodoor();
     doortodoor(int eid,std::string name,double salary,float experience,double samount,double crate,int home);
     void display();
    friend std::ostream& operator <<(std::ostream& , doortodoor &);

};

#endif // SALESMANAGER_H
