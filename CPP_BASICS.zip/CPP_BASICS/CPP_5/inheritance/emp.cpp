#include "emp.h"

employee::employee():emp_id(123),salary(15000),experience(2),name("Bob")
{
       calculatedallowance();
      std::cout<<"def comst call"<<std::endl;
}

employee::employee(int em_id,std::string sname,double amount,float exp):emp_id(em_id),salary(amount),name(sname),experience(exp)
{
       calculatedallowance();
      std::cout<<"para const call"<<std::endl;
}

double employee::calculatesalary()
{
    return salary-HRA-PA-PTAX-PT;
}

void employee::display()
{
    std::cout<<"Employee id "<<emp_id<<std::endl;
    std::cout<<"Employee Salary "<<salary<<std::endl;
    std::cout<<"Employee experience "<<experience<<std::endl;
    std::cout<<"Employee name "<<name<<std::endl;
}

employee::~employee()
{
    std::cout<<"employee dest call"<<std::endl;
}

std::ostream& operator <<(std::ostream& out, employee &p)
{
    out<<"Employee id "<<p.emp_id<<std::endl;
    out<<"Employee Salary "<<p.salary<<std::endl;
    out<<"Employee experience "<<p.experience<<std::endl;
    out<<"Employee name "<<p.name<<std::endl;
    return out;
}