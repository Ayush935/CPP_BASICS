#include "salesperson.h"
#include "emp.h"
#include "manager.h"
#include "salesmanager.h"

int main(){
    // employee e1;
    // e1.display();
    // std::cout<<"Actual Salary"<<e1.calculatesalary()<<std::endl;

    // salesperson s1;
    // s1.display();
    // std::cout<<"Actual Salary"<<s1.calculatesalary()<<std::endl;

    // manager m1;
    // std::cout<<m1<<std::endl;

    // doortodoor t1;
    // std::cout<<t1<<std::endl;

    employee * E1 = new salesperson;
    std::cout<<E1->calculatesalary();
    delete E1;

    salesperson sp1;
    employee * E2 = &sp1;
    std::cout<<E2->calculatesalary();

    E1 = new manager;
    std::cout<<E1->calculatesalary();
    delete E1;

}