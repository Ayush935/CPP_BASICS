#ifndef MANAGER_H
#define MANAGER_H

#include "emp.h"

class manager:public employee
{
   int numberof_subordinates;
   double incenttyper_subordinates;

   public:
   manager();
   manager(int,std::string,double,float,int,int);
   void display();
   double calculatesalary();
   ~manager();
   friend std::ostream& operator <<(std::ostream& , manager &);
};

#endif // MANAGER_H
