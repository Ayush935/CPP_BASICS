#ifndef SALESPERSON_H
#define SALESPERSON_H

#include "emp.h"

class salesperson:public employee
{
    double salesamount,commrate;

    public:
       salesperson();
       salesperson(int,std::string,double,float,double,double);
       void display();
       ~salesperson();
       double calculatesalary();
       friend std::ostream& operator <<(std::ostream& , salesperson &);

};

#endif // SALESPERSON_H
