#include "manager.h"


manager::manager():numberof_subordinates(100),incenttyper_subordinates(10)
{
   std::cout<<"manager def call"<<std::endl;
}

manager::manager(int eid,std::string sname,double psalary,float pexperience,int pnum,int psub):employee(eid,sname,psalary,pexperience),
numberof_subordinates(pnum),incenttyper_subordinates(psub)
{
   std::cout<<"manager def call"<<std::endl;
}

void manager::display()
{
    employee::display();
    std::cout<<"Number of subordinate "<<numberof_subordinates<<std::endl;
    std::cout<<"Incenttyper subordinate "<<incenttyper_subordinates<<std::endl;
}

double manager::calculatesalary()
{
    return employee::calculatesalary()+numberof_subordinates*incenttyper_subordinates;
}

std::ostream& operator<<(std::ostream&out,manager &p)
{   
    // out<<(employee&)p;                 //typecasting
    out<<static_cast<employee&>(p);  
    out<<"Number of subordinate "<<p.numberof_subordinates<<std::endl;
    out<<"Incenttyper subordinate "<<p.incenttyper_subordinates<<std::endl;
    return out;
}

manager::~manager()
{
    std::cout<<"manager dest call"<<std::endl;
}