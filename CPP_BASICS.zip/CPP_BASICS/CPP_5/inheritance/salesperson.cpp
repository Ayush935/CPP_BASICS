#include "salesperson.h"

salesperson::salesperson():salesamount(100),commrate(23)
{
    std::cout<<"salesperson def const call"<<std::endl;
}

salesperson::salesperson(int eid,std::string name,double salary,float experience,double samount,double crate):employee(eid,name,salary,experience),
salesamount(samount),commrate(crate)
{
    std::cout<<"salesperson para const call"<<std::endl;
}

void salesperson::display()
{
   employee::display();
   std::cout<<"salesperson salesamount "<<salesamount<<std::endl;
   std::cout<<"salesperson commraye "<<commrate<<std::endl;
}

salesperson::~salesperson()
{
  std::cout<<"salesperson dest call"<<std::endl;
}

std::ostream& operator <<(std::ostream& out, salesperson &p)
{  //out<<(employee&)p; 
   out<<static_cast<employee&>(p);  
   out<<"salesperson salesamount "<<p.salesamount<<std::endl;
   out<<"salesperson commraye "<<p.commrate<<std::endl;
   return out;
}
double salesperson::calculatesalary()
{
     return employee::calculatesalary()+salesamount*commrate;
}
