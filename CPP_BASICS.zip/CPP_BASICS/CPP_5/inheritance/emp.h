#ifndef EMP_H
#define EMP_H

#include <iostream>


// a class with virtusl function is called polymorphic class
// a class without virtual function is called concrete class
class employee{
     private:
       int emp_id;
       std:: string name;
       double salary;
       double HRA,PA,PTAX,PT;
       float experience;

       void calculatedallowance(){
          HRA = salary*0.02;
          PA=salary*0.03;
          PTAX=salary*0.05;
          PT=salary*0.02;
       }

    public:
      employee();
      employee(int,std::string,double,float);
      virtual ~employee();
      virtual double calculatesalary();
      void display();
      friend std::ostream& operator <<(std::ostream& out, employee &p);
};

#endif // EMP_H
