#include "salesmanager.h"

   doortodoor::doortodoor():salesperson(),houses(50)
     {
    std::cout<<"doortodoor def const call"<<std::endl;
     }

     doortodoor::doortodoor(int eid,std::string name,double salary,float experience,double samount,double crate,int home):salesperson(eid,name,salary,experience,samount,crate),
     houses(home)
     {
      std::cout<<"doortodoor para const call"<<std::endl;
     }

     void doortodoor::display()
     {
     salesperson::display();
     std::cout<<"Houses "<<houses<<std::endl;
     }

     std::ostream& operator <<(std::ostream& out, doortodoor &p)
     {
      out<<static_cast<employee&>(p); 
      out<<"houses "<<p.houses<<std::endl;
      return out;
     }