#include <iostream>

class Animal
{
   std::string type;
   int age;

   public:
   Animal():type("Tiger"),age(12)
   {
     std::cout<<"def const animal call"<<std::endl;
   }
   Animal(std::string ty,int num):type(ty),age(num)
   {
     std::cout<<"para const animal call"<<std::endl;
   }
   void makesound()
   {
    std::cout<<"Roar "<<std::endl;
   }
   void eat()
   {
    std::cout<<"meat "<<std::endl;
   }
   void display()
   {
    std::cout<<"Type "<<type<<std::endl;
    std::cout<<"age "<<age<<std::endl;
   }
};

class cat:public Animal
{
   std::string color;

   public:
   cat():color("white")
   {
     std::cout<<"def const cat call"<<std::endl;
   }
   cat(std::string ty,int num,std::string color):Animal(ty,num),color("black")
   {
     std::cout<<"para const cat call"<<std::endl;
   }
   void makesound()
   {
    std::cout<<"meow "<<std::endl;
   }
   void eat()
   {
    std::cout<<"fish "<<std::endl;
   }
   void display()
   {
    Animal::display();
    std::cout<<"color "<<color<<std::endl;
   }
};

class dog:public Animal
{
   int weight;

   public:
   dog():weight(30)
   {
     std::cout<<"def const dog call"<<std::endl;
   }
   dog(std::string ty,int num,int weg):Animal(ty,num),weight(weg)
   {
     std::cout<<"para const dog call"<<std::endl;
   }
   void makesound()
   {
    std::cout<<"bark "<<std::endl;
   }
   void eat()
   {
    std::cout<<"chicken "<<std::endl;
   }
   void display()
   {
    Animal::display();
    std::cout<<"weight "<<weight<<std::endl;
   }
};

int main()
{
   cat c1;
   c1.eat();
   c1.display();
   
}