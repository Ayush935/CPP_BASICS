#include <iostream>

class vehicle
{
  std::string type;
  std::string color;

  public:
  vehicle():type("bicycle"),color("black")
  {
     std::cout<<"def const veh call"<<std::endl;
  }
  vehicle(std::string as,std::string bs):type(as),color(bs)
  {
     std::cout<<"para const veh call"<<std::endl;
  }
  void drive()
  {
    std::cout<<"bicycle drive"<<std::endl;
  }
};

class bike:public vehicle
{
  std::string name;
  

  public:
  bike():name("Honda")
  {
     std::cout<<"def const bikoe call"<<std::endl;
  }
  bike(std::string as,std::string bs,std::string ss):vehicle(as,bs),name(ss)
  {
     std::cout<<"para const bijke call"<<std::endl;
  }
  void drive()
  {
    std::cout<<"bike drive"<<std::endl;
  }
};

class car:public vehicle
{
  std::string name;
  

  public:
  car():name("Ferrari")
  {
     std::cout<<"def const car call"<<std::endl;
  }
  car(std::string as,std::string bs,std::string ss):vehicle(as,bs),name(ss)
  {
     std::cout<<"para const car call"<<std::endl;
  }
  void drive()
  {
    std::cout<<"car drive"<<std::endl;
  }
};

int main()
{
    bike b1;
    b1.drive();

    car c1;
    c1.drive();
}