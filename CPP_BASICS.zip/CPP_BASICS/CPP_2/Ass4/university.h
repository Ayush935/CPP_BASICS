#ifndef UNIVERSITY_H
#define UNIVERSITY_H

#include <iostream>

class university{

    int enroll_id;
    std::string name;
    int credits;
    int *marks;
    static int p;

    public:
    university();
    university(int,std::string,int*);
    university(const university &p);
    int sum();
    ~university();
    void display();

    std::string getName() const { return name; }
    void setName(const std::string &name_) { name = name_; }

    int getCredits() const { return credits; }
    void setCredits(int credits_) { credits = credits_; }

    int enrollId() const { return enroll_id; }
    void setEnrollId(int enrollId) { enroll_id = enrollId; }

    
};

#endif // UNIVERSITY_H
