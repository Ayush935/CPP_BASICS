#include "function.h"

int university::p=1000;
int university::sum(){
  int sp=0;
  for(int i=0;i<3;i++){
    sp=sp+marks[i];
  }
  return sp;
}

university::university():name("Bob"),credits(100){

  p++;
  enroll_id=p;
  marks = new int[3];
  marks[0]=88;
  marks[1]=55;
  marks[2]=99;
  std::cout<<"def const call"<<std::endl;
}

university::university(int cr,std::string nm,int *mp):name(nm),credits(cr){
  p++;
  enroll_id=p;
  marks=new int[3];
  for(int i=0;i<3;i++){
    this->marks[i]=mp[i];
  }
}

university::~university(){

    delete []marks;
    std::cout<<"Dest call"<<std::endl;

}

void university::display(){
  std::cout<<"enroll id "<<enroll_id<<std::endl;
  std::cout<<"name "<<name<<std::endl;
  std::cout<<"credits "<<credits<<std::endl;
  for(int i=0;i<3;i++){
    std::cout<<"marks "<<i<<" "<<marks[i]<<std::endl;
  }
}