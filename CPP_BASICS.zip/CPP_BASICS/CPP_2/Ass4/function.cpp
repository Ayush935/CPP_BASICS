#include "function.h"

void max(university *s[],int n){
   int maxi=0;
   for(int i=0;i<n;i++){
     if(maxi<s[i]->sum()){
        maxi = s[i]->sum();
     }
   }
   std::cout<<" max is "<<maxi<<std::endl;
}

void givname(university *s[],int n){
    std::string t;
    for(int i=0;i<3;i++){
        if(s[i]->getCredits() == n){
            t=s[i]->getName();
        }
    }
    std::cout<<"The name is "<<t<<std::endl;
}