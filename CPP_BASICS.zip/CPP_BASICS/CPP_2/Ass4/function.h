#include "university.h"

void max(university *[],int);
void givname(university *[],int);

