#include "function.h"

int main(){

    university s;
    s.display();
    
    int m1[3]={45,56,78};
    int m2[3]={56,65,87};
    int m3[3]={45,67,78};


    university *p[3];

    p[0]=new university{99,"John",m1};
    p[1]=new university{111,"Ran",m2};
    p[2]=new university{121,"jack",m3};

    max(p,3);
    givname(p,111);
    for(int i=0;i<3;i++){
        p[i]->display();
    }
}