// private is a helper function
// l value
// containment
// const and refernce needed to be initialize at same line and can be initialise using member initialiser list
#include <iostream>

class mobile{

    //checknumber();
   const int p;

   public:
   mobile():p(123){

   }
   void message(){

   }
};