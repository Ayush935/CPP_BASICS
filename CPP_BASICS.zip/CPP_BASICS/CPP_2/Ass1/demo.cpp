#include <iostream>

class Bankaccount{
    int accno;
    std::string custname;
    double balance;
    static double interestrate;
    static int acc_count;

    public:
    Bankaccount():custname("John"),balance(70000){
       acc_count++;
       accno = acc_count;
    }

    Bankaccount(std::string cname,double b):custname(cname),balance(b){
       acc_count++;
       accno = acc_count;
    }
    static void print(){
        std::cout<<"Interest Rate "<<interestrate<<std::endl;
    }

    void display(){
        std::cout<<"Account number "<<accno<<std::endl;
        std::cout<<"Customer Name "<<custname<<std::endl;
        std::cout<<"Account Balance "<<balance<<std::endl;
        std::cout<<"Interst Rate "<<interestrate<<std::endl;
        std::cout<<std::endl;
    }


};

double Bankaccount::interestrate=7.5;
int Bankaccount::acc_count=1000;

int main(){
    Bankaccount::print();
    Bankaccount b1;
    b1.display();

    Bankaccount b2("Bob",10000);
    b2.display();

}