#include <iostream>

// values can be asigned from right to left and not from left to right
// int a=0,int b,int c=9   this can't be change 
void sum(int a,int b=0,int c=0){   // default value can be anything
    int add= a+b+b;
    std::cout<<"The Sum is "<<add<<std::endl;
}

int main(){
    sum(10,9,6);
    sum(15,10);
    sum(10);
}