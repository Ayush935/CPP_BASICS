#include <iostream>

// function overloading polymorphism

class demo
{
public:

// in function overloading return type  is not included
// two or more functions with same name but with different argument list is called as function overloading
// note : return type ios not considered 
    void add(int a, int b)
    {
        std::cout << "int + int =" << a + b;
    }
    void add(float a, float b)
    {
        std::cout << "float + float =" << a + b;
    }
    void add(float a,int b){
        std::cout<<"float + int ="<<a+b;
    }

};

int main(){
    demo d;
    d.add(4.5f,8.7f);

    return 0;

}