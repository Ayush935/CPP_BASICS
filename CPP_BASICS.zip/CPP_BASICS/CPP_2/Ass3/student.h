#ifndef STUDENT_H
#define STUDENT_H

#include <iostream>

class student
{

    int roll_no; // data members
    std::string name;
    int *marks;

public:                                     // intialisation
    student();                              // default constructer
    student(int a, std::string nm, int *c); // paramitarized constructor
    student(const student &p);              // copy constructor
    ~student();                             // Destructor
    void display();                         // display member function
    double calculateaverage();

    int getrollNo() const { return roll_no; }
    void setRollNo(int rollNo) { roll_no = rollNo; }

    std::string getName() const { return name; }
    void setName(const std::string &name_) { name = name_; }
    
};

#endif // STUDENT_H
