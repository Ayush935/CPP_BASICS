#include "student.h"

void showavg(student *s[],int size){                 //find the maximum average
    double avg[size];
    for(int i=0;i<size;i++){
        avg[i]=s[i]->calculateaverage();
    }

    double max = avg[0];
    for(int i=0;i<size;i++){
        if(max<avg[i]){
            max=avg[i];
        }
    }
    std::cout<<"Maximum average "<<max<<std::endl;
}

bool search(student *s[],int size,int r){
    for(int i=0;i<size;i++){
        if(s[i]->getrollNo()==r)
        return true;
    }
    return false;
}

int main()
{
    student s1;
    s1.display();

    int arr[3] = {55, 66, 77};
    student s2(21, "Bob", arr);
    s2.display();

    student s3(s2);
    s3.display();

    int m1[]={45,56,76};
    int m2[]={54,65,76};
    int m3[]={56,78,87};

    student *s[3];
    s[0]=new student(101,"Jack",m1);
    s[1]=new student(102,"George",m2);
    s[2]=new student(103,"Shiro",m3);

    bool f=search(s,3,102);
    if(f)
    std::cout<<"Student found"<<std::endl;
    else
    std::cout<<"Not found"<<std::endl;

    showavg(s,3);
}