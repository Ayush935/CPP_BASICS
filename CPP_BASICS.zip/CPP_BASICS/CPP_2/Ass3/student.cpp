#include "student.h"

double student::calculateaverage(){
    int sum=0;
    for(int i=0;i<3;i++){
        sum+=marks[i];
    }
    return sum/3.0;
}

student::student() : roll_no(23), name("Bob")
{                       // default constructor
    marks = new int[3]; // memory allocation for 3 integers
    this->marks[0] = 89;
    this->marks[1] = 98;
    this->marks[2] = 68;
}

student::student(int r, std::string nm, int *c) : roll_no(r), name(nm)
{                       // paraamatrized constructor
    marks = new int[3]; // memory allocation for 3 integers
    for (int i = 0; i < 3; i++)
    {
        marks[i] = c[i];
    }
}

student::student(const student &p)
{ // copy constuctor deep copy

    marks = new int[3];
    for (int i = 0; i < 3; i++)
    {
        this->marks[i] = p.marks[i];
    }
    this->roll_no = p.roll_no;
    this->name = p.name;
}

student::~student()
{ // destructor
    delete[] marks;
    std::cout << "destructor called " << std::endl;
}

void student::display()
{
    std::cout << "Student Roll NO " << roll_no << std::endl;
    std::cout << "Student Name " << name << std::endl;
    std::cout << "Student Marks " << std::endl;
    for (int i = 0; i < 3; i++)
    {
        std::cout << "marks " << marks[i] << std::endl;
    }
}
