#include "product.h"

int main(){
    product p1;
    p1.display();

    product p2("laptop");
    p2.display();

    product p3(p2);
    p3.display();

    product *ptr = new product("bag");
    ptr->display();

    delete ptr;
}