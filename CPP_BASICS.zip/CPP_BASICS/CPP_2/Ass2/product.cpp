#include "product.h"
#include <cstring>

product::product(){
    pname = new char[10];
    strcpy(pname,"Mobile");
}

product::~product(){
    delete []pname;
    std::cout<<" ~product (destructor) called \n";
}

product::product(const char *nm){
    pname = new char[strlen(nm)+1];
    strcpy(pname,nm);
}

product::product(const product &p){
   this->pname = new char[strlen(p.pname)+1];
   strcpy(this->pname,p.pname);
}

void product::display(){
    std::cout<<"Product Name "<<pname<<std::endl;
}