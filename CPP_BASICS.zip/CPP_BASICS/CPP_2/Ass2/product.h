#ifndef PRODUCT_H
#define PRODUCT_H

#include <iostream>

class product
{
    char *pname;

public:
    product();
    product(const char *);
    product(const product &p);
    void display();
    ~product();   // cannot be overloaded
};

#endif // PRODUCT_H
