#include <iostream>

class player{
    int a;
    int b;

    public:
    player(){

    }
    player(int c,int d){
          a=c;
          b=d;

    }
    void display(){
        std::cout<<"value of a "<<a<<std::endl;
        std::cout<<"value of b "<<b<<std::endl;
    }

    player operator +(player p){
        player temp;
        temp.a=a+p.a;
        temp.b=b+p.b;
        return temp;
    }
};

int main(){
    player a1(4,7);
    player a2(7,8);
    player a3;

    a3=a1+a2;
    a3.display();



}