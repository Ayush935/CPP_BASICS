#include <iostream>

class address{
    std::string city;
    int pincode;

    public:
    address():city("bombay"),pincode(35434){
        std::cout<<"def att call"<<std::endl;
    }
    address(std::string nm,int pn):city(nm),pincode(pn){
        std::cout<<"para const call"<<std::endl;
    }
    void display(){
        std::cout<<"City "<<city<<std::endl;
        std::cout<<"Pincode "<<pincode<<std::endl;
    }
};

class student{
    int roll_no;
    std::string name;
    address add;

    public:
    student():roll_no(55),name("Bob"){
        std::cout<<"def stu call"<<std::endl;
    }
    student(int r,std::string pn,std::string nm,int pm):roll_no(r),name(pn),add(nm,pm){
        std::cout<<"para stu call"<<std::endl;
    }
    void display(){
        std::cout<<"roll_no "<<roll_no<<std::endl;
        std::cout<<"name "<<name<<std::endl;
        add.display();

    }
};



int main(){

    student s1(12,"Jack","Pune",2312);
    s1.display();

}