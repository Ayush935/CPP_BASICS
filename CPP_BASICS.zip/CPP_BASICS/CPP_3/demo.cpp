// private is a helper function
// l value
// containment
// const and refernce needed to be initialize at same line and can be initialise using member initialiser list
#include <iostream>

class mobile{

    //checknumber();
   const int p;

   public:
   mobile():p(123){

   }
   void message(){

   }
};

// containment has a relation
// reusability
// one object as a part of another

// composition
class engine{

};
class car{
    engine e;
};

//Agreegation
class person{};
class b{
    person *p;
};