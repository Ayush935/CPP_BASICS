#include <iostream>

enum level{
      orange,green,yellow
    };

class student{
    int roll_no;
    std::string name;
    enum level type;

    public:
    student():roll_no(32),name("Bob"),type(level::green){}
    student(int t,std::string p,enum level st):roll_no(t),name(p),type(st){}

    void setRollNo(int rollNo) { roll_no = rollNo; }

    void setName(const std::string &name_) { name = name_; }

    void setType(const enum level &type_) { type = type_; }

    void show();
    
    
};

void student::show(){
    std::cout<<"rn"<<roll_no<<" nm"<<name;
    switch (type)
    {
    case 0:
        std::cout<<" orange";
        break;
    case 1:
        std::cout<<" green";
        break;
    case 2:
        std::cout<<" yellow";
        break;
    
    
    }
}

void 

int main(){

}