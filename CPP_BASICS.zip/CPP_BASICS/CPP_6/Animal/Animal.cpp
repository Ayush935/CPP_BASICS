#include <iostream>

class Animal
{
   std::string name;
   int of;
   int age;
};