#include <iostream>

class doctor
{
   public:
   
};