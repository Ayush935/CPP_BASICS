#include <iostream>

class shape
{
   std::string color;
   int number_of_sides;

   public:
   shape():color("Red"),number_of_sides(4)
   {

   }
   void fillcolor()
   {

   }

   virtual void calArea() = 0;
};

class circle:public shape
{
   float radius;

   public:
   circle():radius(0.5)
   {

   }
   void calArea()
   {
    std::cout<<"Area of circle is "<<(float)(3.14*(radius *radius));
   }
};

class square:public shape
{
   float side;

   public:
   square():side(8)
   {
   
   }
   void calArea()
   {
    std::cout<<"Area of square is "<<side*side<<std::endl;
   }
};

class rectangle:public shape
{
    float l,b;

    public:
    rectangle():l(10),b(20)
    {

    }
    void calArea()
    {
        std::cout<<"Area of rectangle is "<<l*b<<std::endl;
    }
};

int main()
{
    circle c1;
    shape &ref = c1;
    try
    {
        circle &href = dynamic_cast<circle&>(ref);
        href.calArea();
    }
    catch(const std::bad_cast& e)
    {
        std::cerr << e.what() << '\n';
    }
    
    shape *d = new circle;
    // std::cout<<typeid(*d).name();

    if(typeid(*d)==typeid(circle))
    {
        circle *s = dynamic_cast<circle*>(d);
        s->calArea();

    }
    else if(typeid(*d)==typeid(square))
    {
        square *p = dynamic_cast<square*>(d);
        p->calArea();
    }
    else if(typeid(*d)==typeid(rectangle))
    {
        rectangle *r = dynamic_cast<rectangle*>(d);
        r->calArea();
    }
}

