#include "bus.h"


bus::bus(){
    std::cout<<"Default constructor called \n";
    bus_no=123;
    strcpy(bname,"DNR");
    price=1000;
}

bus::bus(int a,const char*ps,int d){
    bus_no=a;
    strcpy(bname,ps);
    price=d;
}

void bus::display(){
    std::cout<<" Bus number "<<bus_no<<" Bus Name "<<bname<<" Bus price "<<price<<std::endl;
}