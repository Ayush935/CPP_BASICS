#include "bus.h"

int main(){
    bus b;
    b.display();

    bus b1(102,"Purple",200);
    b1.display();

    bus*bc[2];
    bc[0]=new bus(103,"ARB",300);
    bc[1]=new bus(104,"St",400);

    for(int i=0;i<2;i++)
    bc[i]->display();

    bus *vtr = new bus;
    vtr->display();

    delete vtr;

    return 0;
}