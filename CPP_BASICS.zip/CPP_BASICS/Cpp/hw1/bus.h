#include <iostream>
#include <cstring>

class bus{

    int bus_no;
    char bname[20];
    int price;

    public:
    bus();
    bus(int a, const char *ps,int b);
    void display();

    int busNo() const { return bus_no; }
    void setBusNo(int busNo) { bus_no = busNo; }

    char *getBname() { return bname; }
    void setBname(const char *bn) { strcpy(bname,bn); }

    int getPrice() const { return price; }
    void setPrice(int price_) { price = price_; }

    
};