#include <iostream>

int main(){
    // int a=10;
    // int b=20;            // we wre giving the file in read only manner
    // const int *p = &a;   // p is a pointer to constant variable
    // p=&b;                // p is a non constant pointer to constant integer

    // *p=20;
     
    // int a=10;
    // int b=20;
    // int *const p = &a;   // p is a constant pointer to non constant integer
    // p=&b;
    // *p=20;

    int a=10;
    int b=20;
    const int const*p = &a; // constant pointer to constant integer
    return 0;
}