#include "bank.h"

int main(){
    bank b1;
    b1.display();

    bank b2(23,"SBI",20000);
    b2.display();

    bank *c[2];
    c[0]=new bank{102,"ICIC",30000};
    c[1]=new bank{103,"HDFC",40000};
    
    for(int i=0;i<2;i++)
    c[i]->display();

    bank *pc = new bank;
    pc->display();

    delete pc;

    return 0;
   
}