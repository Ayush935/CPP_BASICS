#ifndef BANK_H
#define BANK_H

#include <iostream>
#include <cstring>

class bank{
    int account_Id;
    char accname[20];
    int balance;

    public:
    bank();
    bank(int n,const char *p,int c);
    void display();

    int accountId() const { return account_Id; }
    void setAccountId(int a) { account_Id = a; }

    char * getAccname()  { return accname; }
    void setAccname(const char *an) { strcpy(accname,an); }

    int getBalance() const { return balance; }
    void setBalance(int balance_) { balance = balance_; }
    
};

#endif // BANK_H
