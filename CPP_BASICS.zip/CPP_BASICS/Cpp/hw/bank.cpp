#include "bank.h"
#include <cstring>


bank::bank(){
    std::cout<<"default const called \n";
    account_Id=123;
    strcpy(accname,"John");
    balance=2000;

}

bank::bank(int n,const char *an,int r){
     account_Id=n;
    strcpy(accname,an);
    balance=r;
}    

void bank::display(){
    std::cout<<" Account ID "<<account_Id<<" Account Name "<<accname<<" balance "<<balance<<std::endl;
}