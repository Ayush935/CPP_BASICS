#include <iostream>

void exchange(int&,int&);

int main(){
    int a,b;
    std::cout<<"Enter the numbers a and b : ";   // cout is an object of ostream class
    std::cin>>a>>b;                      // cin is an object of istream class
    // int max;
    // if(a>b){
    //     max = a;
    // }
    // else{
    //     max=b;
    // }
    // std::cout<<"The max number is : "<<max<<std::endl;

    // exchange(a,b);  // a nad b local to main function
    // std::cout<<"numbers are "<<std::endl<<"a="<<a<<std::endl<<"b="<<b;

     // no memory is allocated to refrence
    //pointers are flexible
    int *p = &a;   // pointer can override the address it is stored but refrence can't be change, they are rigid
    int &c = a;   // a referece can locate to only one variable
    c = b;
    // int &d = 10;
    std::cout<<"value of c is ";
    std::cout<<c;

    return 0;
}

void exchange(int &a,int &b){
    int temp;
    temp = b;
    b=a;
    a=temp;

}