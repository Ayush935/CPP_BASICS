#include<iostream>

class student{

    int roll_no;
    char sname[20];
    int marks;

    public:
    void display(){
     
    std::cout<<"Roll No "<<roll_no<<" sname "<<sname<<" marks "<<marks;
    }
};

int main(){
    student s1;  // 
    s1.display();
    return 0;
}