#ifndef SHOP_H
#define SHOP_H

#include <iostream>
#include <cstring>

class shop{

  int shop_no;
  char stype[20];
  int pnumbers;

  public:
  shop();
  shop(int,const char *,int);
  void display();

  int shopNo() const { return shop_no; }
  void setShopNo(int shopNo) { shop_no = shopNo; }

  char *getStype() { return stype; }
  void setStype(const char *np) { strcpy(stype,np); }

  int getPnumbers() const { return pnumbers; }
  void setPnumbers(int pnumbers_) { pnumbers = pnumbers_; }

  
};

#endif // SHOP_H
