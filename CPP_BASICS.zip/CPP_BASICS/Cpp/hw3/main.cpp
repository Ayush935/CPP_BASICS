#include "shop.h"

int main(){
    shop s1;
    s1.display();

    shop s2(234,"Market",300);
    s2.display();

    shop *s[2];
    s[0]=new shop(256,"Super Market",1000);
    s[1]=new shop(234,"Medical Store",200);

    for(int i=0;i<2;i++)
    s[i]->display();

    shop *ptr = new shop;
    ptr->display();

    delete ptr;

    return 0;
}