#include "shop.h"
#include <cstring>

shop::shop()
{
    std::cout << "shop default const called \n";
    shop_no = 162;
    strcpy(stype, "Grocerry");
    pnumbers = 50;
}

shop::shop(int a,const char *sp,int s){
    shop_no = a;
    strcpy(stype, sp);
    pnumbers = s;
}

void shop::display(){
    std::cout<<" Shop Number "<<shop_no<<" Shop Type "<<stype<<" Product numbers "<<pnumbers<<std::endl;
}