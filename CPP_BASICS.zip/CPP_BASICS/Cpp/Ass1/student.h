#include <iostream>
#include <cstring>

class student{
    int roll_no;
    char sname[20];
    int marks;
    
    public:
    student();
    student(int,const char*,int);
    void display();

    //get and set function

    int getRollno(){return roll_no;}
    char *getName(){return sname;}
    int getMarks(){return marks;}

    void setRollno(int r){roll_no=r;}
    void setname(const char *nm){ strcpy(sname,nm);}
    void setMarks(int m){marks=m;}

};