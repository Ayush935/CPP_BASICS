#include "student.h"
#include<cstring>

student::student(){
    std::cout<<"Student called \n";

    roll_no=101;
    strcpy(sname,"John");
    marks=88;
}

student::student(int r,const char *name,int k){
    roll_no=r;
    strcpy(sname,name);
    marks=k;

}

void student::display(){
    std::cout<<"Roll_No "<< roll_no <<" Name "<< sname <<" Marks "<< marks << std::endl;
}