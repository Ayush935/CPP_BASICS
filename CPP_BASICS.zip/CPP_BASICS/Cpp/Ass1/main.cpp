#include "student.h"

int main(){
    student *s[3];
    s[0]= new student(102,"Bob",98);
    s[1]= new student(103,"Jack",78);
    s[2]= new student(102,"Jacob",96);

    for(int i=0;i<3;i++)
    s[i]->display();

    student s1;
    s1.display();

    student s2(103,"Anna",89);
    s2.setMarks(59);
    std::cout<<"Mrks are "<<s2.getMarks()<<std::endl;

    student *sptr = new student;
    sptr->display();

    delete sptr; // avoid memory leakage

    return 0;

}