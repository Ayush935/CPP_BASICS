#include "product.h"

int main(){

    product p1;
    p1.display();

    product p2(123,"Box",90);
    p2.display();

    product *s[3];
    s[0]=new product{121,"bat",30};
    s[1]=new product{124,"ball",130};
    s[2]=new product{126,"slate",60};

    for(int i=0;i<3;i++)
    s[i]->display();

    product *p = new product;
    p->display();

    delete p;
}