#ifndef PRODUCT_H
#define PRODUCT_H

#include <iostream>
#include <cstring>

class product
{

    int product_id;
    char pname[20];
    int price;

public:
    product();
    product(int l, const char *n, int d);
    void display();

    int getProduct_ID()
    {
        return product_id;
    }
    char *getPname()
    {
        return pname;
    }
    int getPrice()
    {
        return price;
    }

    void setProduct_ID(int p)
    {
        product_id = p;
    }
    void setPname(const char *n)
    {
        strcpy(pname, n);
    }
    void setPrice(int z)
    {
        price = z;
    }
};

#endif // PRODUCT_H
