#include "product.h"
#include <cstring>

product::product(){
    std::cout<<"default constructor called \n";
    
    product_id=123;
    strcpy(pname,"Soap");
    price=50;
}

product::product(int r,const char *p,int k){
    product_id=r;
    strcpy(pname,p);
    price=k;
}

void product::display(){
    std::cout<<" Product_ID "<<product_id<<" Product Name "<<pname<<" Price "<<price<<std::endl;
}