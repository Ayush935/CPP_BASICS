#include <iostream>

enum type{
   salary,savings,current
};

class bankaccount
{
    int balance;
    int withdrawal;
    enum type pt;

    public:
    bankaccount();
    bankaccount(int,int,enum type pt);
    virtual void show();
    enum type getPt() const { return pt; }
    void setPt(const enum type &pt_) { pt = pt_; }
    friend std::istream& operator>>(std::istream&,bankaccount &);
    friend std::ostream& operator<<(std::ostream&,bankaccount &);
    



};