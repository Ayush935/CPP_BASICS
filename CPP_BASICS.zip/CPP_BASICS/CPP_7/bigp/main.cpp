#include "person.h"

int main()
{
    // person *S = new person;
    // std::cin>>*S;
    // std::cout<<*S;
    
    bankaccount *p = new person;
   
    if(typeid(*p)==typeid(person)){
        person *tp = dynamic_cast<person *>(p);
        if(p==0){
            std::cout<<"wrong"<<std::endl;
        }
        else{
            tp->pp();
        }
    }
    else{
        std::cout<<"no ty"<<std::endl;
    }
    // delete S;
    delete p;
}