#include "bankaccount.h"

class person:public bankaccount
{
    std::string name;

    public:
    person();
    person(int,int,enum type ,std::string);
    void show();
    void pp();
     friend std::istream& operator>>(std::istream&,person &);
    friend std::ostream& operator<<(std::ostream&,person &);
};