#include "person.h"

person::person():bankaccount(),name("bob")
{

}

person::person(int a,int b,enum type c,std::string nam):bankaccount(a,b,c),name(nam)
{

}

void  person::show(){
        std::cout<<"call peron"<<"\n";
    }
void person::pp(){
        std::cout<<"dynamic cast"<<std::endl;
    }

std::istream& operator>>(std::istream&in,person &other)
{
    in>>static_cast<bankaccount &>(other);
    std::cout<<"enter name"<<std::endl;
    in>>other.name;
    std::cout<<std::endl;
    return in;
}

std::ostream& operator<<(std::ostream&out,person &other)
{
    out<<static_cast<bankaccount &>(other);
    out<<"name"<<std::endl;
    out<<other.name<<std::endl;
    return out;
} 