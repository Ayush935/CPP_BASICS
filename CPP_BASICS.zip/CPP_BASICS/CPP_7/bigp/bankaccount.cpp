#include "bankaccount.h"

bankaccount::bankaccount():balance(1000),withdrawal(200),pt(type::savings)
{
    
}
bankaccount::bankaccount(int a,int b,enum type c):balance(a),withdrawal(b),pt(c)
{
     
}

void bankaccount::show()
{
    std::cout<<"bankaccount"<<std::endl;
}

std::istream& operator>>(std::istream&in,bankaccount &other){
    std::cout<<"bal"<<std::endl;
    int a;
    in>>a;
    try{
        if(a<0){
            throw std::invalid_argument("invalid value");
        }
        other.balance=a;
    }
    catch(std::exception &e){
        std::cout<<e.what()<<std::endl;
        std::cout<<"new balance"<<std::endl;
        in>>other.balance;
    }
    std::cout<<"wd"<<std::endl;
    in>>other.withdrawal;
    std::cout<<"\n";
    std::cout<<"type"<<std::endl;
    int c;
    in>>c;
    switch(c){
        case 0:
        other.setPt(salary);
        break;
        case 1:
        other.setPt(savings);
        break;
        case 2:
        other.setPt(current);
        break;
    }
    return in;

}

std::ostream& operator<<(std::ostream&out,bankaccount &other)
{
    out<<"bal"<<" "<<other.balance<<std::endl;
    out<<"wd"<<" "<<other.withdrawal<<std::endl;
    out<<"type"<<" ";
    switch(other.pt){
        case 0:
        std::cout<<"salary";
        break;
        case 1:
        std::cout<<"savings";
        break;
        case 2:
        std::cout<<"current";
        break;
    }
    out<<std::endl;
    return out;

}

