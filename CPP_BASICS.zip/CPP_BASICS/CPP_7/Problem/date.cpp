#include "date.h"

date::date() : day(10), month(12), year(2001)
{
}

date::date(int a, int b, int c) : day(a), month(b), year(c)
{
}

std::ostream &operator<<(std::ostream &out, date &other)
{
    out << "Date " << other.day << " " << other.month << " " << other.year << "\n";
    return out;
}

void date::accept()
{
    std::cout << "Enter Date ";
    if ((month >= 1 && month <= 12) && (day >= 1 && day <= 31))
    {
        if (month == 2)
        {
            if (day >= 1 && day <= 28)
            {
                std::cin >> day >> month >> year;
                std::cout << std::endl;
            }
            else
            {
                std::cout << "incorrect date" << std::endl;
            }
        }
        else
        {
            std::cin >> day >> month >> year;
            std::cout << std::endl;
        }
    }
    else
    {
        std::cout << "incorrect date" << std::endl;
        std::cout << std::endl;
    }
}

