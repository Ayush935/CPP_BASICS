#include "bill.h"

bill::bill() : billnumber(21), customerinfo(), billdate(), billamount(5000)
{
}

bill::bill(int a, const char *b, int c, int d, int e, int f) : billnumber(a), customerinfo(b), billdate(c, d, e), billamount(f)
{
}

std::ostream &operator<<(std::ostream &out, bill &other)
{
    out << "Billamount" << std::endl;
    out << other.billnumber;
    out << "\n";
    out << other.customerinfo;
    out << "\n";
    out << other.billdate;
    out << "\n";
    out << "billamount " << std::endl;
    out << other.billamount << "\n";
    return out;
}

void bill::accept()
{
    std::cout << "Billnum" << std::endl;
    std::cin >> billnumber;
    customerinfo.accept();
    billdate.accept();
    std::cout << "Billamount" << std::endl;
    std::cin >> billamount;
    std::cout << "\n";
}

bill::~bill()
{
}