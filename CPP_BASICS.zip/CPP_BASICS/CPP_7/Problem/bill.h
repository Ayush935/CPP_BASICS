#ifndef BILL_H
#define BILL_H

#include "date.h"

class bill
{
    int billnumber;
    customer customerinfo;
    date billdate;
    int billamount;

public:
    bill();
    bill(int, const char *, int, int, int, int);

    int getBillnumber() const { return billnumber; }
    void setBillnumber(int billnumber_) { billnumber = billnumber_; }

    // customer getCustomerinfo() const { return customerinfo.getCustomername(); }
    // void setCustomerinfo(const customer &customerinfo_)
    // {
    //     customerinfo = customerinfo_;
    // }

    // const date &getBilldate() const { return billdate; }
    // void setBilldate(const date &billdate_) { billdate = billdate_; }

    char *getCustomerinfo() const
    {
        return customerinfo.getCustomername();
    }

    friend std::ostream &operator<<(std::ostream &out, bill &other);
    void accept();
    ~bill();

    int getBillamount() const { return billamount; }
    void setBillamount(int billamount_) { billamount = billamount_; }
};

#endif // BILL_H
