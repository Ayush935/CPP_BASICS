#include "customer.h"

customer::customer()
{
    customername = new char[10];
    strcpy(customername, "Bob");
}

customer::customer(const char *name)
{
    customername = new char(strlen(name) + 1);
    strcpy(customername, name);
}

customer::customer(customer &other)
{
    customername = new char(strlen(other.customername) + 1);
    strcpy(customername, other.customername);
}

void customer::accept()
{
    std::cout << "Enter Customer Name" << std::endl;
    std::cin >> customername;
    std::cout << std::endl;
}

std::ostream &operator<<(std::ostream &out, customer &other)
{
    out << "Customer Name"
        << " " << other.customername << "\n";
    out << "\n";
    return out;
}

customer::~customer()
{
    delete[] customername;
}
