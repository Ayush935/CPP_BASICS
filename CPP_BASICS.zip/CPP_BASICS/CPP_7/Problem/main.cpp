#include "bill.h"

void totalbillamount(bill *p){
    int sum=0;
    for(int i=0;i<3;i++){
        sum=sum+p[i].getBillamount();
    }
    std::cout<<"total billamount "<<sum<<std::endl;
}

void find( char name[10],bill *p){
    for(int i=0;i<3;i++){
        if(strcmp(p[i].getCustomerinfo(),name)==0){
             std::cout<<p[i]<<std::endl;
             break;
        }; 
    }

}

int main()
{
    bill *ptr = new bill[3];
    for(int i=0;i<3;i++){
        ptr[i].accept();
    }
    for(int i=0;i<3;i++){
        std::cout<<ptr[i];
    }

    totalbillamount(ptr);
    char nm[10];
    std::cout<<"Enter name"<<std::endl;
    std::cin>>nm;
    find(nm,ptr);

    delete [] ptr;
}