#include "template.h"

int main()
{
    int arr[5]={5,3,4,2,6};
    sort(arr,5);
    display(arr,5);
}