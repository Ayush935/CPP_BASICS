#include <iostream>


template<class T> void sort(T a[],int n)
{
    for(int i=0;i<n-1;i++){
        for(int j=0;j<n-i-1;j++){
            if(a[j]<a[j+1]){
                int temp;
                temp  = a[j];
                a[j]=a[j+1];
                a[j+1]=temp;
            }
        }
    }
};

template<class T> void display(T arr[],int n)
{
    for(int i=0;i<n;i++){
        std::cout<<arr[i]<<" ";
    }
}
