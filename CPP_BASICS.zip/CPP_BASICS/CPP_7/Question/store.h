#include <iostream>>

class store
{
    int model_number;
    int quantity;

    public:
    store();
    store(int,int);

};