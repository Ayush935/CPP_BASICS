#include "store.h"

class product
{
    
};