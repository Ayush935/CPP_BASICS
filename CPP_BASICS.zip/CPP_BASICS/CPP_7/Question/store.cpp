#include "store.h"

store::store():model_number(123),quantity(55)
{
   
}

store::store(int num,int quant):model_number(num),quantity(quant)
{

}

