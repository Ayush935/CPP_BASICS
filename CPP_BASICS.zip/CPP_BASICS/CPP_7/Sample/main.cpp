#include "sample.h"

class product{
    int productid;
    int price;

    public:
    product()
    {
        productid=123;
        price=100;
    }
    product(int z,int s)
    {
        productid=z;
        price=s;
    }
    friend std::ostream& operator<<(std::ostream&out,product &other)
    {
        out<<"Enter product id and price"<<" ";
        out<<other.productid<<" "<<other.price;
        return out;
    }
    friend std::istream& operator>>(std::istream&is,product &other)
    {
        std::cout<<"Enter product id and price"<<" ";
        is>>other.productid>>other.price;
        return is;
    }
};

int main()
{
    sample<product>p;
    // product p1;
    // std::cin>>p1;
    // std::cout<<p1;
    // p.accept();
    // p.display();
    std::cin>>p;
    std::cout<<p;
}