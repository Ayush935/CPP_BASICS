#include <iostream>

template<class T>
class sample
{
   T *arr;
   int size;

   public:
   sample();
   sample(T*,int);
   void accept();
   void display();
   friend std::ostream& operator<<(std::ostream &,sample&);
   friend std::istream& operator>>(std::istream &,sample&);
};

template<class T>
sample<T>::sample():size(20)
{
    arr = new T[3];
    
}

template<class T>
sample<T>::sample(T* p,int z):size(z)
{   
    arr = new T[3];
    for(int i=0;i<3;i++)
    {
        arr[i]=p[i];
    }
}

// template<class T>
// void sample<T>::accept()
// {
//     std::cout<<"Enter size"<<std::endl;
//     std::cin>>size;
//     std::cout<<std::endl;
//     std::cout<<"Enter array"<<std::endl;
//     for(int i=0;i<3;i++){
//       std::cin>>arr[i];
//     }
//     std::cout<<std::endl;
// }

// template<class T>
// void sample<T>::display()
// {
//     std::cout<<"size "<<std::endl;
//     std::cout<<size;
//     std::cout<<std::endl;
//     std::cout<<"array "<<std::endl;
//     for(int i=0;i<3;i++){
//       std::cout<<arr[i]<<" ";
//     }
//     std::cout<<std::endl;
// }

template<class T>
std::ostream& operator<<(std::ostream &out,sample<T> &other)
{
     for(int i=0;i<3;i++){
        out<<other.arr[i]<<" ";
     }
     out<<std::endl;
     out<<other.size<<std::endl;
     return out;
}

template<class T>
std::istream& operator>>(std::istream &in ,sample<T> &other)
{
     std::cout<<"enter"<<std::endl;
     for(int i=0;i<3;i++)
     {
        in >> other.arr[i];
     }
     std::cout<<std::endl;
     std::cout<<"Size"<<std::endl;
     in >> other.size;
     std::cout<<std::endl;
     return in;
}