#include <iostream>

template<class T>
class product
{
    T *arr;
    int size;

    public:
    product();
    product(T *,int);
    friend std::ostream& operator<<(std::ostream &,product&);
    friend std::istream& operator>>(std::istream &,product&);
    ~product();
    void display();

};

template<class T>
product<T>::product()
{
    size = 2;
    arr = new T[3];
}

template<class T>
product<T>::product(T *mk,int s):size(s)
{
    
    arr = new T[3];
    for(int i=0;i<3;i++){
        arr[i]=mk[i];
    }
}

// template<class T>
// std::ofstream& operator<<(std::ostream &out,product &other)
// {
//      for(int i=0;i<3;i++){
//         out<<other.arr[i]<<" ";
//      }
//      out<<std::endl;
//      out<<other.size<<std::endl;
//      return out;
// }

// template<class T>
// std::istream& operator>>(std::istream &in ,product &other)
// {
//      std::cout<<"enter"<<std::endl;
//      for(int i=0;i<3;i++)
//      {
//         in >> other.arr[i];
//      }
//      std::cout<<std::endl;
//      std::cout<<"Size"<<std::endl;
//      in >> other.size;
//      std::cout<<std::endl;
//      return in;
// }
