#include "product.h"

int main()
{   
    int mk[3]={2,1,3};
    product <int> p1;

    std::cin>>p1;
    std::cout<<p1;

}