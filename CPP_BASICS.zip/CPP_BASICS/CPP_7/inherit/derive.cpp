#include "derive.h"

void b::show()
{
    std::cout<<"call b"<<std::endl;
}

void b::pc()
{
    std::cout<<"calling pc b"<<std::endl;
}