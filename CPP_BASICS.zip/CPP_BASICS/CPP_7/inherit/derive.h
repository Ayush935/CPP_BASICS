#include "base.h"

class b:public A
{
   public:
   void show();
   void pc();
};