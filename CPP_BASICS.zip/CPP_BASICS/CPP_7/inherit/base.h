#include <iostream>

class A
{
    int d;
    int c;
    
    public:
     A();
     void show();
     void operator-();
     friend A operator+(A &,int);
     
    //  A operator+(int);

     int getD() const { return d; }
     void setD(int d_) { d = d_; }

     int getC() const { return c; }
     void setC(int c_) { c = c_; }
};