#include "base.h"

A::A():d(10),c(20)
{

}

void A::operator-()
{
    d=-d;
    c=-c;
}

void A::show()
{
    std::cout<<d<<" "<<c<<std::endl;
}

// A A::operator+(A &other)
// { 
//     A temp;
//     temp.d=d+other.d;
//     temp.c=c+other.c;
//     return temp;

// }

A operator+(A &s,int n)
{
    A t;
    t.d = n + s.d;
    t.c = n + s.c;
    return t;
}

// A A::operator+(int n)
// {
//     A temp;
//     temp.d = d+n;
//     temp.c= c+n;
//     return temp;
// }