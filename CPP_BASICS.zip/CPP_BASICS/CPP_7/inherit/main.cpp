#include "derive.h"

int main()
{
    A bcd;
    -bcd;
    bcd.show();
    // A cd = bcd + bcd;
    // cd.show();
     A cd = bcd + 10;
    cd.show();
    // as->show();
    // as->A::show();
    // as->pc();
}